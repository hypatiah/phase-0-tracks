#Form Tags and Their Purpose

Full name: 
  - input type: text input area <input type="text" name="fullname">

Email:
 - input type: text input area that must be in email format (with @...) <input type="email" name="email">
 
Password:
- input type: text input area that masks characters as bullet points <input type="password" name="password">

Adventure name:
 - input type: text input area <input type="text" name="adv-name" placeholder="Name this adventure">

Type of bicycle:
- input type: select <select> from predetermined options <option value="">

Choose a date:
- input type: date selection using <input type="date" name="date">

I'm prepared to lead adventure: 
- input type: true/false "checkbox" input, <input type="checkbox" name="cb-agree" value="agree">
